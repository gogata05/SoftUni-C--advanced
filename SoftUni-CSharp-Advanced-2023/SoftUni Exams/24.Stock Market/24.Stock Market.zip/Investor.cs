﻿using System;
using System.Collections.Generic;
using System.Text;
namespace StockMarket
{
    public class Investor
    {
        public Investor(string fullName, string emailAddress, decimal moneyToInvest, string brokerName)
        {
            FullName = fullName;
            EmailAddress = emailAddress;
            MoneyToInvest = moneyToInvest;
            BrokerName = brokerName;
            Portfolio = new Dictionary<string, Stock>();
        }

        public string FullName { get; set; }
        public string EmailAddress { get; set; }
        public decimal MoneyToInvest { get; set; }
        public string BrokerName { get; set; }
        private Dictionary<string, Stock> Portfolio { get; set; }

        public int Count => Portfolio.Count;

        public void BuyStock(Stock stock)
        {
            if (stock.MarketCapitalization > 10000m && MoneyToInvest >= stock.PricePerShare)
            {
                Portfolio[stock.CompanyName] = stock;
                MoneyToInvest -= stock.PricePerShare;
            }
        }

        public string SellStock(string companyName, decimal sellPrice)
        {
            if (!Portfolio.ContainsKey(companyName))
                return $"{companyName} does not exist.";

            var stock = Portfolio[companyName];

            if (sellPrice < stock.PricePerShare)
                return $"Cannot sell {companyName}.";

            MoneyToInvest += sellPrice;
            Portfolio.Remove(companyName);

            return $"{companyName} was sold.";
        }

        public Stock FindStock(string companyName)
        {
            if (Portfolio.TryGetValue(companyName, out var stock))
                return stock;

            return null;
        }

        public Stock FindBiggestCompany()
        {
            if (Portfolio.Count == 0)
                return null;

            var maxMarketCap = new KeyValuePair<string, Stock>(null, null);
            foreach (var pair in Portfolio)
            {
                if (maxMarketCap.Value == null || pair.Value.MarketCapitalization > maxMarketCap.Value.MarketCapitalization)
                    maxMarketCap = pair;
            }

            return maxMarketCap.Value;
        }

        public string InvestorInformation()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"The investor {FullName} with a broker {BrokerName} has stocks:");

            foreach (var stock in Portfolio.Values)
            {
                sb.AppendLine(stock.ToString());
            }

            return sb.ToString();
        }
    }
}

