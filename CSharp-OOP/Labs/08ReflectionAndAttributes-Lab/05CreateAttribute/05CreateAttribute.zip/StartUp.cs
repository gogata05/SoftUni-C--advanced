﻿[Author("Victor")]
class StartUp
{
    [Author("George")]
    static void Main()
    {

    }
}