﻿using BookingApp.Models.Hotels;
using BookingApp.Models.Rooms;
using BookingApp.Models.Bookings;
using BookingApp.Utilities.Messages;
using System;
using System.Linq;
using BookingApp.Core.Contracts;
using BookingApp.Models.Rooms.Contracts;
using BookingApp.Repositories;
using System.Text;

namespace BookingApp.Core
{
    public class Controller : IController
    {
        private HotelRepository hotels;
        public Controller()
        {
            this.hotels = new HotelRepository();
        }

        public string AddHotel(string hotelName, int category)
        {
            if (this.hotels.All().Any(h => h.FullName == hotelName))
            {
                return string.Format(OutputMessages.HotelAlreadyRegistered, hotelName);
            }

            var hotel = new Hotel(hotelName, category);
            this.hotels.AddNew(hotel);

            return string.Format(OutputMessages.HotelSuccessfullyRegistered, category, hotelName);
        }

        public string UploadRoomTypes(string hotelName, string roomTypeName)
        {
            var hotel = this.hotels.All().FirstOrDefault(h => h.FullName == hotelName);

            if (hotel == null)
            {
                return string.Format(OutputMessages.HotelNameInvalid, hotelName);
            }

            if (hotel.Rooms.All().Any(r => r.GetType().Name == roomTypeName))
            {
                return OutputMessages.RoomTypeAlreadyCreated;
            }

            IRoom room = roomTypeName switch
            {
                "Apartment" => new Apartment(),
                "Studio" => new Studio(),
                "DoubleBed" => new DoubleBed(),
                _ => throw new ArgumentException(ExceptionMessages.RoomTypeIncorrect),
            };

            hotel.Rooms.AddNew(room);

            return string.Format(OutputMessages.RoomTypeAdded, roomTypeName, hotelName);
        }

        public string SetRoomPrices(string hotelName, string roomTypeName, double price)
        {
            var hotel = this.hotels.All().FirstOrDefault(h => h.FullName == hotelName);

            if (hotel == null)
            {
                return string.Format(OutputMessages.HotelNameInvalid, hotelName);
            }

            var room = hotel.Rooms.All().FirstOrDefault(r => r.GetType().Name == roomTypeName);

            if (room == null)
            {
                return $"HotelNameInvalid";

            }

            if (room.PricePerNight > 0)
            {
                throw new InvalidOperationException(ExceptionMessages.PriceAlreadySet);
            }

            room.SetPrice(price);

            return string.Format(OutputMessages.PriceSetSuccessfully, roomTypeName, hotelName);
        }

        public string BookAvailableRoom(int adults, int children, int duration, int category)
        {
            var hotels = this.hotels.All()
                .Where(h => h.Category == category)
                .OrderBy(h => h.FullName)
                .ToList();

            if (!hotels.Any())
            {
                return string.Format(OutputMessages.CategoryInvalid, category);
            }

            foreach (var hotel in hotels)
            {
                var rooms = hotel.Rooms.All()
                    .Where(r => r.PricePerNight > 0 && r.BedCapacity >= adults + children)
                    .OrderBy(r => r.BedCapacity)
                    .ToList();

                if (rooms.Any())
                {
                    var room = rooms.First();
                    var bookingNumber = hotel.Bookings.All().Count + 1;
                    var booking = new Booking(room, duration, adults, children, bookingNumber);
                    hotel.Bookings.AddNew(booking);

                    return string.Format(OutputMessages.BookingSuccessful, bookingNumber, hotel.FullName);
                }
            }

            return OutputMessages.RoomNotAppropriate;
        }

        public string HotelReport(string hotelName)
        {
            var hotel = this.hotels.All().FirstOrDefault(h => h.FullName == hotelName);

            if (hotel == null)
            {
                return string.Format(OutputMessages.HotelNameInvalid, hotelName);
            }

            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Hotel name: {hotel.FullName}");
            sb.AppendLine($"--{hotel.Category} star hotel");
            sb.AppendLine($"--Turnover: {hotel.Turnover:F2} $");
            sb.AppendLine("--Bookings:");

            if (hotel.Bookings.All().Any())
            {
                foreach (var booking in hotel.Bookings.All())
                {
                    sb.AppendLine(booking.BookingSummary());
                }
            }
            else
            {
                sb.AppendLine("none");
            }

            return sb.ToString().TrimEnd();
        }
    }
}
