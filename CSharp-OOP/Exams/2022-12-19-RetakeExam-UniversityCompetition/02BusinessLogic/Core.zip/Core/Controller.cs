﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using UniversityCompetition.Core.Contracts;
using UniversityCompetition.Models;
using UniversityCompetition.Models.Contracts;
using UniversityCompetition.Repositories;
using UniversityCompetition.Utilities.Messages;
namespace UniversityCompetition.Core
{
    public class Controller : IController
    {
        private SubjectRepository subjects;
        private StudentRepository students;
        private UniversityRepository universities;
        public Controller()
        {
            this.subjects = new SubjectRepository();
            this.students = new StudentRepository();
            this.universities = new UniversityRepository();
        }

        public string AddStudent(string firstName, string lastName)
        {
            if (this.students.Models.Any(s => s.FirstName == firstName && s.LastName == lastName))
            {
                return string.Format(OutputMessages.AlreadyAddedStudent, firstName, lastName);
            }
            var student = new Student(this.students.Models.Count + 1, firstName, lastName);
            this.students.AddModel(student);
            return string.Format(OutputMessages.StudentAddedSuccessfully, firstName, lastName, nameof(StudentRepository));
        }

        public string AddSubject(string subjectName, string subjectType)
        {
            if (this.subjects.Models.Any(s => s.Name == subjectName))
            {
                return string.Format(OutputMessages.AlreadyAddedSubject, subjectName);
            }
            ISubject subject = subjectType switch
            {
                "TechnicalSubject" => new TechnicalSubject(this.subjects.Models.Count + 1, subjectName),
                "EconomicalSubject" => new EconomicalSubject(this.subjects.Models.Count + 1, subjectName),
                "HumanitySubject" => new HumanitySubject(this.subjects.Models.Count + 1, subjectName),
                _ => throw new ArgumentException(string.Format(OutputMessages.SubjectTypeNotSupported, subjectType)),
            };
            this.subjects.AddModel(subject);
            return string.Format(OutputMessages.SubjectAddedSuccessfully, subjectType, subjectName, nameof(SubjectRepository));
        }

        public string AddUniversity(string universityName, string category, int capacity, List<string> requiredSubjects)
        {
            if (this.universities.Models.Any(u => u.Name == universityName))
            {
                return string.Format(OutputMessages.AlreadyAddedUniversity, universityName);
            }
            var requiredSubjectIds = requiredSubjects.Select(rs => this.subjects.FindByName(rs).Id).ToList();
            var university = new University(this.universities.Models.Count + 1, universityName, category, capacity, requiredSubjectIds);
            this.universities.AddModel(university);
            return string.Format(OutputMessages.UniversityAddedSuccessfully, universityName, nameof(UniversityRepository));
        }

        public string ApplyToUniversity(string studentName, string universityName)
        {
            var student = this.students.FindByName(studentName);
            if (student == null)
            {
                return string.Format(OutputMessages.StudentNotRegitered, studentName.Split(" ")[0], studentName.Split(" ")[1]);
            }
            var university = this.universities.FindByName(universityName);
            if (university == null)
            {
                return string.Format(OutputMessages.UniversityNotRegitered, universityName);
            }
            if (!university.RequiredSubjects.All(rs => student.CoveredExams.Contains(rs)))
            {
                return string.Format(OutputMessages.StudentHasToCoverExams, studentName, universityName);
            }
            if (student.University != null && student.University.Name == universityName)
            {
                return string.Format(OutputMessages.StudentAlreadyJoined, student.FirstName, student.LastName, universityName);
            }
            student.JoinUniversity(university);
            return string.Format(OutputMessages.StudentSuccessfullyJoined, student.FirstName, student.LastName, universityName);
        }

        public string TakeExam(int studentId, int subjectId)
        {
            var student = this.students.FindById(studentId);
            if (student == null)
            {
                return OutputMessages.InvalidStudentId;
            }
            var subject = this.subjects.FindById(subjectId);
            if (subject == null)
            {
                return OutputMessages.InvalidSubjectId;
            }
            if (student.CoveredExams.Contains(subjectId))
            {
                return string.Format(OutputMessages.StudentAlreadyCoveredThatExam, student.FirstName, student.LastName, subject.Name);
            }
            student.CoverExam(subject);
            return string.Format(OutputMessages.StudentSuccessfullyCoveredExam, student.FirstName, student.LastName, subject.Name);
        }

        public string UniversityReport(int universityId)
        {
            var university = this.universities.FindById(universityId);
            var studentsCount = this.students.Models.Count(s => s.University != null && s.University.Id == universityId);
            var capacityLeft = university.Capacity - studentsCount;
            var sb = new StringBuilder();
            sb.AppendLine($"*** {university.Name} ***")
                .AppendLine($"Profile: {university.Category}")
                .AppendLine($"Students admitted: {studentsCount}")
                .AppendLine($"University vacancy: {capacityLeft}");
            return sb.ToString().TrimEnd();
        }


    }
}
